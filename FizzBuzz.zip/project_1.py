def n_doors(n):
    # Initialize all doors as closed (False)
    doors = [False] * n
    
    # For each person (1 to n)
    for i in range(1, n + 1):
        # Toggle every i-th door
        for j in range(i - 1, n, i):
            print(f"i: {i}; j:{j+1}; step size: {i}. Toggling door number {j+1}.")
            doors[j] = not doors[j]
    
    print("\nAlgorithm has finished.")
    
    # Print final state of each door
    for i in range(n):
        state = "open" if doors[i] else "closed"
        print(f"Door number {i+1} remains {state}.")
    
    # Create FizzBuzz list for open doors
    result = []
    for i in range(n):
        if doors[i]:  # If door is open
            num = i + 1
            if num % 3 == 0 and num % 5 == 0:
                result.append("fizzbuzz")
            elif num % 3 == 0:
                result.append("fizz")
            elif num % 5 == 0:
                result.append("buzz")
            else:
                result.append(num)
                
    print(f"\nN Doors Puzzle's Fizz Buzz Implementation: {result}")
    return result

# Example usage
n = 10
print(f"\nDetailed process with n={n} doors:")
open_doors = n_doors(n)
print(f"\nNumber of open doors after {n} people: {open_doors}")

