#include <math.h>
#include "point.h"

void midpoint(Point a, Point b, Point *m) {
    m->x = (a.x + b.x) / 2;
    m->y = (a.y + b.y) / 2;
    m->z = (a.z + b.z) / 2;
}

void distance(Point a, Point b, double *d) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    double dz = a.z - b.z;
    *d = sqrt(dx * dx + dy * dy + dz * dz);
}