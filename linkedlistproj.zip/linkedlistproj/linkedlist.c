#include "linkedlist.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to create a new node
LLNode* createNode(int id, char name[], double gpa) {
    LLNode* newNode = (LLNode*)malloc(sizeof(LLNode));
    if (newNode != NULL) {
        newNode->id = id;
        strcpy(newNode->name, name);
        newNode->gpa = gpa;
        newNode->next = NULL;
    }
    return newNode;
}

// Function to insert a node into the linked list in alphabetical order of the name
LLNode* insertNode(LLNode* head, LLNode* newNode) {
    LLNode* prev = NULL;
    LLNode* curr = head;

    // Find the correct position to insert the new node
    while (curr != NULL && strcmp(curr->name, newNode->name) < 0) {
        prev = curr;
        curr = curr->next;
    }

    // Insert the new node
    if (prev == NULL) {
        newNode->next = head;
        head = newNode;
    } else {
        prev->next = newNode;
        newNode->next = curr;
    }

    return head;
}

// Function to calculate the average GPA of all students in the linked list
double averageGPA(LLNode* head) {
    double sum = 0.0;
    int count = 0;
    LLNode* curr = head;

    // Traverse the linked list and calculate the sum of GPAs
    while (curr != NULL) {
        sum += curr->gpa;
        count++;
        curr = curr->next;
    }

    // Calculate the average GPA
    if (count > 0) {
        return sum / count;
    } else {
        return 0.0; // To avoid division by zero
    }
}

// Function to print the linked list
void printLL(LLNode* head) {
    LLNode* curr = head;
    while (curr != NULL) {
        printf("(%d,%s,%.2f) -> ", curr->id, curr->name, curr->gpa);
        curr = curr->next;
    }
    printf("\n");
}

// Function to recursively deallocate all nodes in the linked list
LLNode* destroyLL(LLNode* head) {
    if (head == NULL) {
        return NULL;
    }
    LLNode* temp = head->next;
    free(head);
    return destroyLL(temp);
}