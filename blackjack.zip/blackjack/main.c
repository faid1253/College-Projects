#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "deck.h"
#include "card.h"
#include "hand.h"

// Contains all the game information
typedef struct Game{
    Hand playerHand;
    Hand dealerHand;
    int playerChips;
    int bet;
    Deck deck;
} Game;

// Function prototypes
void SaveGameToFile(Game game);
Game LoadGameFromFile();
int RunGame(Game* r, int bet);

// Function to run the game
int main(int argc, char* argv[]) {
    Game game;
    int loaded = 0;

    if (argc > 1 && strcmp(argv[1], "load") == 0) {
        loaded = 1;
        game = LoadGameFromFile();
    } else {
        game.playerChips = 1000;
        game.deck = MakeDeck();
    }

    while (game.playerChips > 0) {
        if (!loaded) {
            printf("\nYou have %d chips\n", game.playerChips);
            printf("How much would you like to bet?\n");
            scanf("%d", &game.bet);
            int c;
            while ((c = getchar()) != '\n' && c != EOF) { } // Clear input buffer
            if (game.bet == 0) {
                break; // End the game if bet is 0
            }
            
            // Deal cards
            game.playerHand = MakeHand();
            game.dealerHand = MakeHand();
            AddCard(&game.playerHand, DrawCard(&game.deck));
            AddCard(&game.dealerHand, DrawCard(&game.deck));
            AddCard(&game.playerHand, DrawCard(&game.deck));
            AddCard(&game.dealerHand, DrawCard(&game.deck));
        } else {
            loaded = 0;
        }

        if (CalculatePoints(&game.playerHand) == 21) {
            printf("You were dealt a 21!\n");
            PrintHand(game.playerHand);
            game.playerChips += (int)(double)game.bet / 2.0;
            continue;
        }

        game.playerChips += RunGame(&game, game.bet);
    }

    printf("Game over.\n");
    printf("You left with %d chips.\n", game.playerChips);

    return 0;
}

// Function to run the game round
int RunGame(Game* r, int bet) {
    printf("\n"); // Just to make things pretty

    // Get the player points using CalculatePoints function
    int playerPoints = CalculatePoints(&(r->playerHand));
    if (playerPoints > 21) {
        printf("You busted! You lose the bet.\n");
        return -bet;
    }

    // Print out information on dealer hand and player hand
    printf("Dealer's hand:\n");
    printf("Hidden Card ");
    PrintCard(r->dealerHand.cards[1]);
    printf("\n");
    printf("Your hand:\n");
    PrintHand(r->playerHand);

    // Prompt user to hit, stay, or take a break
    printf("Enter 'h' to hit, 's' to stay, or 'b' to save and exit: ");
    char choice;
    scanf(" %c", &choice);
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { } // Clear input buffer

    if (choice == 'h') {
        // If hit, add a card to player hand and recursive call
        AddCard(&(r->playerHand), DrawCard(&(r->deck)));
        return RunGame(r, bet);
    } else if (choice == 'b') {
        // If break, save game to file and exit program
        SaveGameToFile(*r);
        exit(0);
    } else if (choice == 's') {
        // If stay, resolve the game and return result
        int dealerPoints = CalculatePoints(&(r->dealerHand));
        while (dealerPoints < 16) {
            AddCard(&(r->dealerHand), DrawCard(&(r->deck)));
            dealerPoints = CalculatePoints(&(r->dealerHand));
        }
        printf("Dealer's hand:\n");
        PrintHand(r->dealerHand);
        
        if (dealerPoints > 21 || playerPoints > dealerPoints) {
            printf("Congratulations! You win!\n");
            return bet;
        } else if (dealerPoints == playerPoints) {
            printf("It's a tie! You get your bet back.\n");
            return 0;
        } else {
            printf("Sorry, you lose.\n");
            return -bet;
        }
    }

    return 0;
}

// Function to save game to file
void SaveGameToFile(Game game) {
    FILE *file = fopen("save.txt", "w");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    // Write game data to file
    fprintf(file, "%d\n", game.playerChips);
    fprintf(file, "%d\n", game.bet);

    // Write remaining cards in the deck
    fprintf(file, "%d\n", game.deck.top);
    for (int i = 0; i < game.deck.top; i++) {
        fprintf(file, "%d\n", game.deck.cards[i].value);
        fprintf(file, "%d\n", game.deck.cards[i].suit);
    }

    // Save player and dealer hands to file
    for (int i = 0; i < game.playerHand.handSize; i++) {
        fprintf(file, "%d\n", game.playerHand.cards[i].value);
        fprintf(file, "%d\n", game.playerHand.cards[i].suit);
    }
    fprintf(file, "-1\n"); // Separate player's and dealer's hands
    for (int i = 0; i < game.dealerHand.handSize; i++) {
        fprintf(file, "%d\n", game.dealerHand.cards[i].value);
        fprintf(file, "%d\n", game.dealerHand.cards[i].suit);
    }

    fclose(file);
}

// Function to load game from file
Game LoadGameFromFile() {
    FILE *file = fopen("save.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    // Read game data from file
    Game game;
    fscanf(file, "%d", &game.playerChips);
    fscanf(file, "%d", &game.bet);

    // Read remaining cards in the deck
    fscanf(file, "%d", &game.deck.top);
    for (int i = 0; i < game.deck.top; i++) {
        fscanf(file, "%d", &game.deck.cards[i].value);
        fscanf(file, "%d", &game.deck.cards[i].suit);
    }

    // Load player and dealer hands from file
    int value, suit;
    game.playerHand = MakeHand();
    while (fscanf(file, "%d", &value) != EOF) {
        if (value == -1) break; // End of player's hand
        fscanf(file, "%d", &suit);
        AddCard(&game.playerHand, MakeCard(value, suit));
    }
    game.dealerHand = MakeHand();
    while (fscanf(file, "%d", &value) != EOF) {
        fscanf(file, "%d", &suit);
        AddCard(&game.dealerHand, MakeCard(value, suit));
    }

    fclose(file);

    return game;
}