#ifndef SORTING_H
#define SORTING_H

typedef struct {
    char origin[4];
    char destination[4];
    char *other_data;
} Entry;

Entry *read_file(const char *filename, int *num_entries);
void bubble_sort(Entry *entries, int size);
void quick_sort(Entry *entries, int low, int high);
int partition(Entry *entries, int low, int high);
void merge_sort(Entry *entries, int size);
void merge(Entry *entries, int left, int mid, int right);
void write_sorted_data(const char *filename, Entry *entries, int size);
void print_times(double times[3]);
void free_entries(Entry *entries, int size);

#endif
