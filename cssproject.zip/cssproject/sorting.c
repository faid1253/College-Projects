#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sorting.h"

Entry *read_file(const char *filename, int *num_entries) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        return NULL;
    }

    char line[1024];
    int capacity = 100;
    Entry *entries = malloc(capacity * sizeof(Entry));
    if (entries == NULL) {
        fclose(fp);
        return NULL;
    }

    int i = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        if (i >= capacity) {
            capacity *= 2;
            entries = realloc(entries, capacity * sizeof(Entry));
            if (entries == NULL) {
                fclose(fp);
                return NULL;
            }
        }

        char *token = strtok(line, ",");
        strncpy(entries[i].origin, token, 3);
        entries[i].origin[3] = '\0';

        token = strtok(NULL, ",");
        strncpy(entries[i].destination, token, 3);
        entries[i].destination[3] = '\0';

        entries[i].other_data = malloc(strlen(line) + 1);
        if (entries[i].other_data == NULL) {
            fclose(fp);
            free_entries(entries, i);
            return NULL;
        }
        strcpy(entries[i].other_data, line);

        i++;
    }

    fclose(fp);
    *num_entries = i;
    return entries;
}

void bubble_sort(Entry *entries, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (strcmp(entries[j].origin, entries[j + 1].origin) > 0 ||
                (strcmp(entries[j].origin, entries[j + 1].origin) == 0 &&
                 strcmp(entries[j].destination, entries[j + 1].destination) > 0)) {
                Entry temp = entries[j];
                entries[j] = entries[j + 1];
                entries[j + 1] = temp;
            }
        }
    }
}

int partition(Entry *entries, int low, int high) {
    Entry pivot = entries[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (strcmp(entries[j].origin, pivot.origin) < 0 ||
            (strcmp(entries[j].origin, pivot.origin) == 0 &&
             strcmp(entries[j].destination, pivot.destination) <= 0)) {
            i++;
            Entry temp = entries[i];
            entries[i] = entries[j];
            entries[j] = temp;
        }
    }

    Entry temp = entries[i + 1];
    entries[i + 1] = entries[high];
    entries[high] = temp;

    return i + 1;
}

void quick_sort(Entry *entries, int low, int high) {
    if (low < high) {
        int pi = partition(entries, low, high);
        quick_sort(entries, low, pi - 1);
        quick_sort(entries, pi + 1, high);
    }
}

void merge(Entry *entries, int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Entry *L = malloc(n1 * sizeof(Entry));
    Entry *R = malloc(n2 * sizeof(Entry));

    for (i = 0; i < n1; i++) {
        L[i] = entries[left + i];
    }
    for (j = 0; j < n2; j++) {
        R[j] = entries[mid + 1 + j];
    }

    i = 0;
    j = 0;
    k = left;
    while (i < n1 && j < n2) {
        if (strcmp(L[i].origin, R[j].origin) < 0 ||
            (strcmp(L[i].origin, R[j].origin) == 0 &&
             strcmp(L[i].destination, R[j].destination) <= 0)) {
            entries[k++] = L[i++];
        } else {
            entries[k++] = R[j++];
        }
    }

    while (i < n1) {
        entries[k++] = L[i++];
    }

    while (j < n2) {
        entries[k++] = R[j++];
    }

    free(L);
    free(R);
}

void merge_sort(Entry *entries, int size) {
    int curr_size;
    int left_start;

    for (curr_size = 1; curr_size <= size - 1; curr_size = 2 * curr_size) {
        for (left_start = 0; left_start < size - 1; left_start += 2 * curr_size) {
            int mid = left_start + curr_size - 1;
            int right_end = (left_start + 2 * curr_size - 1 < size - 1) ?
                            left_start + 2 * curr_size - 1 :
                            size - 1;

            merge(entries, left_start, mid, right_end);
        }
    }
}

void write_sorted_data(const char *filename, Entry *entries, int size) {
    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        return;
    }

    fprintf(fp, "Origin_airport,Destination_airport,Other_data\n");
    for (int i = 0; i < size; i++) {
        fprintf(fp, "%s,%s,%s", entries[i].origin, entries[i].destination, entries[i].other_data);
    }

    fclose(fp);
}

void print_times(double times[3]) {
    printf("\nFinal Times\n");
    printf("1. MergeSort %.6f seconds\n", times[2]);
    printf("2. QuickSort %.6f seconds\n", times[1]);
    printf("3. BubbleSort %.6f seconds\n", times[0]);
}

void free_entries(Entry *entries, int size) {
    for (int i = 0; i < size; i++) {
        free(entries[i].other_data);
    }
    free(entries);
}