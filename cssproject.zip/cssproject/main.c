#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sorting.h"

int main() {
    Entry *entries = NULL;
    int num_entries = 0;
    entries = read_file("flight_data.csv", &num_entries);

    if (entries == NULL) {
        printf("Error reading file.\n");
        return 1;
    }

    clock_t start, end;
    double times[3];

    Entry *temp_entries = malloc(num_entries * sizeof(Entry));
    if (temp_entries == NULL) {
        printf("Memory allocation failed.\n");
        free_entries(entries, num_entries);
        return 1;
    }

    memcpy(temp_entries, entries, num_entries * sizeof(Entry));

    start = clock();
    bubble_sort(temp_entries, num_entries);
    end = clock();
    times[0] = (double)(end - start) / CLOCKS_PER_SEC;
    write_sorted_data("BubbleSort.csv", temp_entries, num_entries);

    memcpy(temp_entries, entries, num_entries * sizeof(Entry));
    start = clock();
    quick_sort(temp_entries, 0, num_entries - 1);
    end = clock();
    times[1] = (double)(end - start) / CLOCKS_PER_SEC;
    write_sorted_data("QuickSort.csv", temp_entries, num_entries);

    memcpy(temp_entries, entries, num_entries * sizeof(Entry));
    start = clock();
    merge_sort(temp_entries, num_entries);
    end = clock();
    times[2] = (double)(end - start) / CLOCKS_PER_SEC;
    write_sorted_data("MergeSort.csv", temp_entries, num_entries);

    free(temp_entries);
    free_entries(entries, num_entries);

    print_times(times);

    return 0;
}