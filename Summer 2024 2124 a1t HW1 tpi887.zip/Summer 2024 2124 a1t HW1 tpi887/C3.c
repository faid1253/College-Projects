#include <stdio.h>
 int main() { 
FILE *fp; 
char filename[] = "faidh_naife.txt"; 
fp = fopen(filename, "a"); 
if (fp == NULL) {
 printf("Error opening file.\n"); 
return 1; 
} 
fprintf(fp, "887\n"); 
fclose(fp);
 printf("Write: 887 Location: /home/username/Desktop/faidh_naife.txt\n"); 
 printf("Summer 2024 - CS2124 a1t tpi887\n");
return 0; 
}
