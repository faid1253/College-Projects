#include <stdio.h>
 #include <string.h>
 int main() {
char str1[] = "Naife"; 
char str2[] = "Naife"; 
int len1 = strlen(str1); 
int len2 = strlen(str2); 
int minLen = (len1 < len2) ? len1 : len2; 
int diffCount = 0; 
   for (int i = 0; i < minLen; i++) {
       if (str1[i] != str2[i]) {
           diffCount++; } 
} 
int result = diffCount; 
printf("First String: %s\n", str1); printf("Second String: %s\n", str2); 
printf("Return value: %d\n", result);
printf("Summer 2024 - CS2124 a1t tpi887\n");
 return 0;
 }
