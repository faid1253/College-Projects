#include <stdio.h>
            #include <stdlib.h>
int main() { 
int n; 
printf("Enter number of elements (Calloc): "); 
scanf("%d", &n);
int *arr = (int *)calloc(n, sizeof(int)); 
if (arr == NULL) { 
      printf("Memory allocation failed.\n");
      return 1; } 
      printf("Enter elements: "); 
for (int i = 0; i < n; i++) {
 scanf("%d", &arr[i]); }
printf("Memory Address of 1st element: %p\n", (void *)&arr[0]); 
printf("Memory Address of 2nd element: %p\n", (void *)&arr[1]); 
printf("Memory Address of 3rd element: %p\n", (void *)&arr[2]); 
free(arr);
printf("Summer 2024 - CS2124 a1t tpi887\n");

return 0; 
}
