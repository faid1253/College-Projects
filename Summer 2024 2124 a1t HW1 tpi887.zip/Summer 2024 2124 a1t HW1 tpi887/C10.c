#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str1[] = "NaIfe";
    char str2[10]; 
    int result;

    strcpy(str2, str1);
    for (int i = 0; str2[i] != '\0'; i++) {
        str2[i] = toupper(str2[i]);
    }

    result = strcmp(str1, str2);

    printf("First String: %s; String Add: %p\n", str1, (void *)str1);
    printf("Second String: %s; String Add: %p\n", str2, (void *)str2);
    printf("Return value: %d\n", result);
    printf("Summer 2024 - CS2124 a1t tpi887\n");

    return 0;
}