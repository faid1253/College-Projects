#include <stdio.h>

int main() {
    FILE *fp;
    char filename[] = "faidh_naife.txt";
    int char_count = 0;
    char ch;

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    printf("Location: /home/Username/Desktop/student.txt\n");

    printf("File Contain: ");
    while ((ch = fgetc(fp)) != EOF) {
        if (ch != '\n') {
            printf("%c", ch);
            char_count++;
        }
    }
    printf("\n");

    fclose(fp);


    printf("Pointer Location: %d\n", char_count);
    printf("Summer 2024 - CS2124 a1t tpi887\n");

    return 0;
}