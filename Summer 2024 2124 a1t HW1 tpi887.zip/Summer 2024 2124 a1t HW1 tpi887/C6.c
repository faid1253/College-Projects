#include <stdio.h>
#include <string.h> 
int main() { 
char str1[] = "faidh"; 
char str2[100];
 printf("String S1: %s\n", str1); 
printf("String S1 Starting Add: %p\n", (void *)str1); 
strcpy(str2, str1); 
printf("String S2: %s\n", str2); 
printf("String S2 Starting Add: %p\n", (void *)str2); 
printf("String Length: %zu\n", strlen(str1)); 
printf("Summer 2024 - CS2124 a1t tpi887\n");
return 0;
 }
