#include <string.h>
#include <stdio.h>

int main() {
    char str1[] = "Faidh";
    char str2[] = "Naife";
    char result[20];

    
    strcpy(result, str1);
    strcat(result, str2);

    printf("First string: %s Add: %p\n", str1, (void *)str1);
    printf("Second string: %s Add: %p\n", str2, (void *)str2);
    printf("Concatenated string: %s Add: %p\n", result, (void *)result);
    printf("Summer 2024 - CS2124 a1t tpi887\n");
    return 0;
}