#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int element;
    int priority;
} Node;

void insert(Node* pq, int* size, int element, int priority) {
    pq[*size].element = element;
    pq[*size].priority = priority;
    (*size)++;
}

void display(Node* pq, int size) {
    printf("Priority Queue:\n");
    for (int i = 0; i < size; i++) {
        printf("(Element: %d, Priority: %d ) \n", pq[i].element, pq[i].priority);
    }
    printf("\n-----------------------------------------------------\n");
}

void dequeue(Node* pq, int* size) {
    if (*size == 0) {
        printf("Queue is empty!\n");
        return;
    }

    int highestPriorityIndex = 0;
    for (int i = 1; i < *size; i++) {
        if (pq[i].priority > pq[highestPriorityIndex].priority) {
            highestPriorityIndex = i;
        }
    }

    for (int i = highestPriorityIndex; i < *size - 1; i++) {
        pq[i] = pq[i + 1];
    }
    (*size)--;
}

int main() {
    int n;
    printf("--- P-Queue: 5 = Highest, 0 = Lowest ---\n");
    printf("Enter P-Queue Length = ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input. Program terminates.\n");
        return 1;
    }

    Node* pq = (Node*)malloc(n * sizeof(Node));
    int size = 0;

    for (int i = 0; i < n; i++) {
        int element, priority;
        printf("Enter element %d: ", i + 1);
        if (scanf("%d", &element) != 1) {
            printf("Invalid input. Program terminates.\n");
            free(pq);
            return 1;
        }
        printf("Enter priority of element %d: ", i + 1);
        if (scanf("%d", &priority) != 1 || priority < 0 || priority > 5) {
            printf("Invalid input. Program terminates.\n");
            free(pq);
            return 1;
        }
        insert(pq, &size, element, priority);
    }

    printf("--------------Priority Queue Full-----------------\n");
    display(pq, size);
    

    int choice;
    do {
        printf("Dequeue (1 for yes, 0 for exit): ");
        if (scanf("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
            printf("Invalid input. Program terminates.\n");
            free(pq);
            return 1;
        }
        if (choice == 1) {
            dequeue(pq, &size);
            printf("Priority Queue After Dequeue: \n-----------------------------------------------------\n");
            display(pq, size);
        }
    } while (choice != 0);

    free(pq);
    return 0;
}