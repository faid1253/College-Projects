#include <stdio.h>
#include <stdlib.h>

// Define the structure of a tree node
typedef struct TreeNode {
    int key;
    struct TreeNode* left;
    struct TreeNode* right;
    int height;
} TreeNode;

// Function to create a new node with the given key
TreeNode* newNode(int key) {
    TreeNode* node = (TreeNode*)malloc(sizeof(TreeNode));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;
    return node;
}

// Function to get the height of the tree
int height(TreeNode* node) {
    if (node == NULL)
        return 0;
    return node->height;
}

// Function to right rotate the subtree rooted with y
TreeNode* rightRotate(TreeNode* y) {
    TreeNode* x = y->left;
    TreeNode* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = height(y->left) > height(y->right) ? height(y->left) + 1 : height(y->right) + 1;
    x->height = height(x->left) > height(x->right) ? height(x->left) + 1 : height(x->right) + 1;
    return x;
}

// Function to left rotate the subtree rooted with x
TreeNode* leftRotate(TreeNode* x) {
    TreeNode* y = x->right;
    TreeNode* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = height(x->left) > height(x->right) ? height(x->left) + 1 : height(x->right) + 1;
    y->height = height(y->left) > height(y->right) ? height(y->left) + 1 : height(y->right) + 1;
    return y;
}

// Function to get the balance factor of node N
int getBalance(TreeNode* node) {
    if (node == NULL)
        return 0;
    return height(node->left) - height(node->right);
}

// Function to insert a new key into the subtree rooted with node and balance the subtree
TreeNode* insert(TreeNode* node, int key) {
    if (node == NULL)
        return newNode(key);
    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else
        return node;

    node->height = height(node->left) > height(node->right) ? height(node->left) + 1 : height(node->right) + 1;

    int balance = getBalance(node);

    if (balance > 1 && key < node->left->key)
        return rightRotate(node);
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);
    if (balance > 1 && key > node->left->key) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (balance < -1 && key < node->right->key) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Function to print pre-order traversal of the tree
void preOrder(TreeNode* root) {
    if (root != NULL) {
        printf("%d ", root->key);
        preOrder(root->left);
        preOrder(root->right);
    }
}

int main() {
    int nums[] = {1, 2, 3, 4, 5};
    int n = sizeof(nums) / sizeof(nums[0]);

    TreeNode* bst_root = NULL;
    for (int i = 0; i < n; i++) {
        bst_root = insert(bst_root, nums[i]);
    }

    printf("BST Pre-order:\n");
    preOrder(bst_root);
    printf("\n");

    TreeNode* avl_root = NULL;
    for (int i = 0; i < n; i++) {
        avl_root = insert(avl_root, nums[i]);
    }

    printf("Balanced-AVL Pre-order:\n");
    preOrder(avl_root);
    printf("\n");

    return 0;
}