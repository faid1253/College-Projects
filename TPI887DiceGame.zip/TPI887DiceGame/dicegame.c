// dicegame.c
#include "dicegame.h"

// Function to generate a random number between min and max (inclusive)
int getRandomNumber(int min, int max) {
    return rand() % (max - min + 1) + min;
}

// Function to determine round type based on probability
ROUNDTYPE getRoundType() {
    int random_number = getRandomNumber(0, 9);
    if (random_number < 2) {
        return BONUS;
    } else if (random_number < 5) {
        return DOUBLE;
    } else {
        return REGULAR;
    }
}

// Function to calculate points for a round based on round type
int getRoundPoints(ROUNDTYPE roundType) {
    int points;
    switch (roundType) {
        case BONUS:
            points = 200;
            break;
        case DOUBLE:
            points = getRandomNumber(1, 10) * 20;
            break;
        case REGULAR:
        default:
            points = getRandomNumber(1, 10) * 10;
            break;
    }
    return points;
}

// Function to print player points
void printPlayerPoints(int p1, int p2) {
    printf("P1: %d\nP2: %d\n", p1, p2);
}

// Function to print round information
void printRoundInfo(ROUNDTYPE t, int dice, int points) {
    const char* round_type_str;
    switch (t) {
        case BONUS:
            round_type_str = "BONUS";
            break;
        case DOUBLE:
            round_type_str = "DOUBLE";
            break;
        case REGULAR:
        default:
            round_type_str = "REGULAR";
            break;
    }
    printf("Type    : %s\nDICE    : %d\nPOINTS  : %d\n", round_type_str, dice, points);
}