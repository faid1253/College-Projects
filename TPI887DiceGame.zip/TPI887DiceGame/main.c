// main.c
#include <stdio.h>
#include <stdlib.h>
#include "dicegame.h"

int main() {
    // Initialize the random number generator
    srand(time(NULL));
    
    // Define and initialize variables
    int p1_points = 0, p2_points = 0, rounds;
    int current_player = rand() % 2 + 1; // Randomly choose starting player

    // Get the number of rounds from the user
    printf("Enter the number of rounds: ");
    scanf("%d", &rounds);
    
    // Game loop
    for (int i = 0; i < rounds; i++) {
        // Get round type, dice value, and points
        ROUNDTYPE round_type = getRoundType();
        int dice = getRandomNumber(1, 6);
        int points = getRoundPoints(round_type);
        
        // Determine success or failure
        if ((current_player % 2 == 1 && dice % 2 == 1) || (current_player % 2 == 0 && dice % 2 == 0)) {
            // Success: Current player gains points
            if (current_player == 1) {
                p1_points += points;
            } else {
                p2_points += points;
            }
        } else {
            // Failure: Current player incurs penalty
            if (current_player == 1) {
                p1_points -= points;
            } else {
                p2_points -= points;
            }
            // Switch to the other player
            current_player = (current_player == 1) ? 2 : 1;
        }
        
        // Print round information
        printRoundInfo(round_type, dice, points);
        // Print player points
        printPlayerPoints(p1_points, p2_points);
    }

    // Determine and print the final outcome
    if (p1_points > p2_points) {
        printf("Player 1 wins!\n");
    } else if (p1_points < p2_points) {
        printf("Player 2 wins!\n");
    } else {
        printf("It's a tie!\n");
    }

    return 0;
}