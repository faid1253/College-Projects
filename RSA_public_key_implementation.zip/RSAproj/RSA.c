#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Recursive function to calculate GCD
int gcd(int a, int b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// Function to calculate modular multiplicative inverse of e mod phi using Extended Euclidean Algorithm
int modInverse(int e, int phi) {
    int m0 = phi, t, q;
    int x0 = 0, x1 = 1;

    if (phi == 1)
        return 0;

    while (e > 1) {
        q = e / phi;
        t = phi;
        phi = e % phi;
        e = t;
        t = x0;
        x0 = x1 - q * x0;
        x1 = t;
    }

    if (x1 < 0)
        x1 += m0;

    return x1;
}

// Function to perform modular exponentiation
int modExp(int base, int exp, int mod) {
    int result = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1)
            result = (result * base) % mod;
        exp = exp >> 1;
        base = (base * base) % mod;
    }
    return result;
}

// Function to check if a number is prime
int isPrime(int num) {
    if (num <= 1)
        return 0;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return 0;
    }
    return 1;
}

// Function to generate random prime numbers within a range
int generatePrime(int lower, int upper) {
    int prime;
    do {
        prime = rand() % (upper - lower + 1) + lower;
    } while (!isPrime(prime));
    return prime;
}

// Function to generate RSA keys
void generateKeys(int *n, int *e, int *d) {
    int p, q, phi;

    // Generate two distinct random primes p and q
    p = generatePrime(50, 100); // Example range, adjust as needed
    q = generatePrime(50, 100);
    while (p == q) {
        q = generatePrime(50, 100);
    }

    *n = p * q;
    phi = (p - 1) * (q - 1);

    // Choose e such that 1 < e < phi and gcd(e, phi) = 1
    do {
        *e = rand() % (phi - 2) + 2; // ensures 1 < e < phi
    } while (gcd(*e, phi) != 1);

    // Calculate d, the modular inverse of e mod phi
    *d = modInverse(*e, phi);
}

// RSA Encryption function
int encrypt(int m, int e, int n) {
    return modExp(m, e, n);
}

// RSA Decryption function
int decrypt(int c, int d, int n) {
    return modExp(c, d, n);
}

int main() {
    srand(time(0)); // Seed random number generator

    int n, e, d;

    // Generate RSA keys
    generateKeys(&n, &e, &d);

    printf("Public Key: (e=%d, n=%d)\n", e, n);
    printf("Private Key: (d=%d, n=%d)\n", d, n);

    // Test message
    int m = 42;
    printf("Original message: %d\n", m);

    // Encrypt the message
    int c = encrypt(m, e, n);
    printf("Encrypted message: %d\n", c);

    // Decrypt the message
    int decryptedMessage = decrypt(c, d, n);
    printf("Decrypted message: %d\n", decryptedMessage);

    return 0;
}
