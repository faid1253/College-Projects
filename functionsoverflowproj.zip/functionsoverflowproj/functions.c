#include <stdio.h>
#include <limits.h> 
/* Determine whether arguments can be added without overflow for unsigned integers */
int uadd_ok(unsigned x, unsigned y) {
    unsigned sum = x + y;
    return sum >= x && sum >= y;
}

/* Determine whether arguments can be added without overflow for signed integers */
int tadd_ok(int x, int y) {
    int sum = x + y;
    if (x > 0 && y > 0 && sum < 0) return 0; // Positive overflow
    if (x < 0 && y < 0 && sum > 0) return 0; // Negative overflow
    return 1; // No overflow
}

int main() {
    // Test cases for uadd_ok
    printf("uadd_ok tests:\n");
    printf("uadd_ok(1, 2) = %d\n", uadd_ok(1, 2)); // Expected: 1
    printf("uadd_ok(UINT_MAX, 1) = %d\n", uadd_ok(UINT_MAX, 1)); // Expected: 0
    printf("uadd_ok(1000, 1000) = %d\n", uadd_ok(1000, 1000)); // Expected: 1
    printf("uadd_ok(UINT_MAX - 1, 1) = %d\n", uadd_ok(UINT_MAX - 1, 1)); // Expected: 1

    // Test cases for tadd_ok
    printf("\ntadd_ok tests:\n");
    printf("tadd_ok(1, 2) = %d\n", tadd_ok(1, 2)); // Expected: 1
    printf("tadd_ok(INT_MAX, 1) = %d\n", tadd_ok(INT_MAX, 1)); // Expected: 0
    printf("tadd_ok(-1, -2) = %d\n", tadd_ok(-1, -2)); // Expected: 1
    printf("tadd_ok(INT_MIN, -1) = %d\n", tadd_ok(INT_MIN, -1)); // Expected: 0

    return 0;
}