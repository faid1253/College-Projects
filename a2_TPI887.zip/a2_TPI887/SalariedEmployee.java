public class SalariedEmployee extends Employee {
    private double weeklyPay;

    public SalariedEmployee(String name, double weeklyPay) {
        super(name);
        this.weeklyPay = weeklyPay;
    }

   
    public double calcPrebonusPay() {
        return weeklyPay;
    }

    
    public String getJobCode() {
        return "SLRY";
    }
}