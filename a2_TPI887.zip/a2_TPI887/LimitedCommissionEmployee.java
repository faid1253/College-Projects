public class LimitedCommissionEmployee extends CommissionEmployee {
    private double basePay;

    public LimitedCommissionEmployee(String name, double commissionRate, double basePay) {
        super(name, commissionRate);
        this.basePay = basePay;
    }

   
    public double calcPrebonusPay() {
        double commissionPay = super.calcPrebonusPay();
        
        // Pay must be at least base pay
        if (commissionPay < basePay) {
            return basePay;
        }
        
        // Pay cannot exceed twice the base pay
        if (commissionPay > (2 * basePay)) {
            return 2 * basePay;
        }
        
        return commissionPay;
    }

   
    public String getJobCode() {
        return "LCOM";
    }
}

