public class CommissionEmployee extends Employee {
    private double commissionRate;
    private double sales;

    public CommissionEmployee(String name, double commissionRate) {
        super(name);
        this.commissionRate = commissionRate;
        this.sales = 0;
    }

    public void setSales(double sales) {
        this.sales = sales;
    }

   
    public double calcPrebonusPay() {
        return sales * commissionRate;
    }

   
    public String getJobCode() {
        return "COMM";
    }
}