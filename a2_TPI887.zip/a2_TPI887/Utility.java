public class Utility implements PayableEntity {
    private String name;
    private double usage;
    private double rate;
    private double baseFee;

    public Utility(String name, double rate, double baseFee) {
        this.name = name;
        this.rate = rate;
        this.baseFee = baseFee;
        this.usage = 0;
    }

    public void setUsage(double usage) {
        this.usage = usage;
    }

  
    public double getAmountOwed() {
        return (usage * rate) + baseFee;
    }

   
    public String toString() {
        return String.format("%-20s $ %9.2f", name, getAmountOwed());
    }
}