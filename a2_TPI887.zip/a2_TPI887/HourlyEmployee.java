
public class HourlyEmployee extends Employee {
    private double hourlyWage;
    private int hoursWorked;

    public HourlyEmployee(String name, double hourlyWage) {
        super(name);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = 0;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    
    public double calcPrebonusPay() {
        if (hoursWorked <= 40) {
            return hoursWorked * hourlyWage;
        } else {
            return (40 * hourlyWage) + ((hoursWorked - 40) * hourlyWage * 1.5);
        }
    }

    public String getJobCode() {
        return "HRLY";
    }
}