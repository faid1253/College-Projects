public abstract class Employee implements PayableEntity {
    private static int numEmployees = 0;
    protected String name;
    protected double bonus;

    public Employee(String name) {
        this.name = name;
        numEmployees++;
        this.bonus = 0.0; 
    }
    
    public abstract double calcPrebonusPay();
    public abstract String getJobCode();

    public static int getNumEmployees() {
        return numEmployees;
    }

    public String getName() {
        return name;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double calcTotalPay() {
        return calcPrebonusPay() + bonus;
    }

  
    public double getAmountOwed() {
        return calcTotalPay();
    }


    public String toString() {
        return String.format("%-15s %-4s $ %-8.2f $ %6.2f", 
            name, 
            getJobCode(), 
            calcPrebonusPay(), 
            calcTotalPay());
    }
}