public class Company {
    private String name;
    private Employee[] employees;
    private Utility[] utilities;
    private int empCount;
    private int utilCount;

    public Company(String name, int maxEmployees, int maxUtilities) {
        this.name = name;
        this.employees = new Employee[maxEmployees];
        this.utilities = new Utility[maxUtilities];
        this.empCount = 0;
        this.utilCount = 0;
    }

    public String getName() {
        return name;
    }

    public void addEmployee(Employee e) {
        if (empCount < employees.length) {
            employees[empCount++] = e;
        }
    }

    public void addUtility(Utility u) {
        if (utilCount < utilities.length) {
            utilities[utilCount++] = u;
        }
    }

    public String createPayrollListing() {
        StringBuilder sb = new StringBuilder();
        // Title line
        sb.append(String.format("%s Payroll\n", name));
        // Header line 
        sb.append(String.format("%-15s %-5s %8s  %-5s\n", 
            "Name", "Code", "Pay", "Total Pay"));
        // Employee entries
        for (Employee e : employees) {
            if (e != null) {
                sb.append(e.toString()).append("\n");
            }
        }
        return sb.toString();
    }

    public String createUtilityListing() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("%s Utilities\n", name));

        sb.append(String.format("%-20s %-5s\n", 
        			"Name", "Bill Amount"));

        for (Utility u : utilities) {
            if (u != null) {
                sb.append(u.toString()).append("\n");
            }
        }
        return sb.toString();
    }

    private double calcExpenditures(PayableEntity[] entities) {
        double total = 0;
        for (PayableEntity entity : entities) {
            if (entity != null) {
                total += entity.getAmountOwed();
            }
        }
        return total;
    }

    public double calcTotalExpenditures() {
        return calcExpenditures(employees) + calcExpenditures(utilities);
    }
}