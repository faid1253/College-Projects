public interface PayableEntity {
    double getAmountOwed();
}
