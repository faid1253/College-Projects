#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct {
    char items[MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

int isFull(Stack *s) {
    return s->top == MAX - 1;
}

void push(Stack *s, char c) {
    if (!isFull(s)) {
        s->items[++(s->top)] = c;
    }
}

char pop(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[(s->top)--];
    }
    return '\0';
}

char peek(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[s->top];
    }
    return '\0';
}

int isMatchingPair(char left, char right) {
    return (left == '(' && right == ')') ||
           (left == '{' && right == '}') ||
           (left == '[' && right == ']');
}

int checkBalancedParentheses(char *expr) {
    Stack s;
    initialize(&s);
    for (int i = 0; i < strlen(expr); i++) {
        if (expr[i] == '(' || expr[i] == '{' || expr[i] == '[') {
            push(&s, expr[i]);
        } else if (expr[i] == ')' || expr[i] == '}' || expr[i] == ']') {
            if (isEmpty(&s) || !isMatchingPair(pop(&s), expr[i])) {
                return 0;
            }
        }
    }
    return isEmpty(&s);
}

int main() {
    char expr[MAX];
    printf("Enter Expression: ");
    if (fgets(expr, MAX, stdin) != NULL) {
        // Remove newline character if present
        expr[strcspn(expr, "\n")] = '\0';
    }
    
    if (checkBalancedParentheses(expr)) {
        printf("It's Balanced (^_^) Faidh Naife> - TPI887 - Summer 2024\n");
    } else {
        printf("It's Not Balanced (0_0) Faidh naife> - TPI887 - Summer 2024\n");
    }

    return 0;
}