#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX 100

typedef struct {
    char items[MAX];
    int top;
} Stack;

void initialize(Stack *s) {
    s->top = -1;
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

int isFull(Stack *s) {
    return s->top == MAX - 1;
}

void push(Stack *s, char c) {
    if (!isFull(s)) {
        s->items[++(s->top)] = c;
    }
}

char pop(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[(s->top)--];
    }
    return '\0';
}

char peek(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[s->top];
    }
    return '\0';
}

int precedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
    }
    return 0;
}

int isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

void infixToPostfix(char *infix, char *postfix) {
    Stack s;
    initialize(&s);
    int j = 0;
    for (int i = 0; i < strlen(infix); i++) {
        if (isdigit(infix[i]) || isalpha(infix[i])) {
            while (isdigit(infix[i]) || isalpha(infix[i])) {
                postfix[j++] = infix[i++];
                postfix[j++] = ' '; // Add space after each character
            }
            i--; // Adjust i to account for the extra increment in the loop
        } else if (infix[i] == '(') {
            push(&s, infix[i]);
        } else if (infix[i] == ')') {
            while (!isEmpty(&s) && peek(&s) != '(') {
                postfix[j++] = pop(&s);
                postfix[j++] = ' '; // Add space after each character
            }
            pop(&s);  // Remove '('
        } else if (isOperator(infix[i])) {
            while (!isEmpty(&s) && precedence(peek(&s)) >= precedence(infix[i])) {
                postfix[j++] = pop(&s);
                postfix[j++] = ' '; // Add space after each character
            }
            push(&s, infix[i]);
        }
    }
    while (!isEmpty(&s)) {
        postfix[j++] = pop(&s);
        postfix[j++] = ' '; // Add space after each character
    }
    postfix[j] = '\0';
}

int main() {
    char infix[MAX], postfix[MAX];
    printf("Enter the Infix expression: ");
    if (fgets(infix, MAX, stdin) != NULL) {
        // Remove newline character if present
        infix[strcspn(infix, "\n")] = '\0';
    }
    infixToPostfix(infix, postfix);
    printf("The Postfix expression: %s\n", postfix);
    printf("End of Program\n");

    return 0;
}