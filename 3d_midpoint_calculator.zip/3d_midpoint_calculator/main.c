#include <stdio.h>
#include "point.h"

int main() {
    Point a, b, m;
    double d;

    printf("Enter the coordinates of point A (x y z): ");
    scanf("%lf %lf %lf", &a.x, &a.y, &a.z);

    printf("Enter the coordinates of point B (x y z): ");
    scanf("%lf %lf %lf", &b.x, &b.y, &b.z);

    midpoint(a, b, &m);
    distance(a, b, &d);

    printf("midpoint: %.2lf, %.2lf, %.2lf\n", m.x, m.y, m.z);
    printf("distance: %.2lf\n", d);

    return 0;
}