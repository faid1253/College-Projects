#ifndef POINT_H
#define POINT_H

typedef struct {
    double x;
    double y;
    double z;
} Point;

void midpoint(Point a, Point b, Point *m);
void distance(Point a, Point b, double *d);

#endif