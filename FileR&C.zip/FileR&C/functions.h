/* functions.h - Header file */
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// Function prototypes
int compare_strings(const char *str1, const char *str2);
int move_file(const char *source, const char *destination);
int open_and_compare_file(const char *filename, const char *user_input);

#endif /* FUNCTIONS_H */
