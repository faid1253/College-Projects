/* fileopen.c - File opening and comparison implementation */
#include "functions.h"

int open_and_compare_file(const char *filename, const char *user_input) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return errno;
    }
    
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file)) {
        buffer[strcspn(buffer, "\n")] = 0; // Remove newline character
        if (compare_strings(buffer, user_input) == 0) {
            printf("Match found: %s\n", buffer);
            fclose(file);
            return 0;
        }
    }
    
    printf("No match found in file.\n");
    fclose(file);
    return 1;
}
