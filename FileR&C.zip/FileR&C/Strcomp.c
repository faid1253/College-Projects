/* stringcomp.c - String comparison implementation */
#include "functions.h"

int compare_strings(const char *str1, const char *str2) {
    return strcmp(str1, str2);
}
