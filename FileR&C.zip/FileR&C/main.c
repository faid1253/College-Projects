/* main.c - Main program */
#include "functions.h"

int main() {
    // Test string comparison
    char str1[] = "hello";
    char str2[] = "world";
    printf("Comparing '%s' and '%s': %d\n", str1, str2, compare_strings(str1, str2));
    
    // Test file move (Make sure the source file exists before running)
    move_file("test.txt", "new_test.txt");
    
    // Test file open and compare
    char user_input[256];
    printf("Enter a string to compare with file contents: ");
    fgets(user_input, sizeof(user_input), stdin);
    user_input[strcspn(user_input, "\n")] = 0; // Remove newline character
    
    open_and_compare_file("new_test.txt", user_input);
    
    return 0;
}
