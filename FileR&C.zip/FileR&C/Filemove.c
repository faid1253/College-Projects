/* filemov.c - File moving implementation */
#include "functions.h"

int move_file(const char *source, const char *destination) {
    if (rename(source, destination) == 0) {
        return 0; // Success
    } else {
        perror("Error moving file");
        return errno;
    }
}