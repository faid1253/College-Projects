

public class GameOfLife {
 public static void main(String[] args) {
	        boolean[][] initialGen = {
	            {false, true, false},
	            {false, true, false},
	            {false, true, false}
	       };

	        boolean[][] nextGen = GameOfLife.createGeneration(initialGen);
	        int[][] livingCells = GameOfLife.findLivingCellLocations(nextGen);

	        // Print next generation
	        System.out.println("Next Generation:");
	        for (boolean[] row : nextGen) {
	            for (boolean cell : row) {
	                System.out.print(cell ? "1 " : "0 ");
	               }
	            System.out.println();
	       }

	        // Print living cell locations
	        System.out.println("\nLiving Cells:");
	        for (int[] cell : livingCells) {
	            System.out.println("Row: " + cell[0] + ", Col: " + cell[1]);
	       }
	    }
	

    // Method to generate the next generation
    public static boolean[][] createGeneration(boolean[][] currentGen) {
        int rows = currentGen.length;
        int cols = currentGen[0].length;
        boolean[][] nextGen = new boolean[rows][cols];
        
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int livingNeighbors = countLivingNeighbors(currentGen, r, c);
                
                if (currentGen[r][c]) {
                    // Rule 1 & 2: Living cell survives only if it has 2 or 3 neighbors
                    nextGen[r][c] = (livingNeighbors == 2 || livingNeighbors == 3);
                } else {
                    // Rule 3: Dead cell becomes alive if it has exactly 3 neighbors
                    nextGen[r][c] = (livingNeighbors == 3);
                }
            }
        }
        return nextGen;
    }
    
    // Helper method to count living neighbors
    public static int countLivingNeighbors(boolean[][] grid, int row, int col) {
        int count = 0;
        int rows = grid.length;
        int cols = grid[0].length;
        
        // Loop over the 8 possible neighbors
        for (int r = row - 1; r <= row + 1; r++) {
            for (int c = col - 1; c <= col + 1; c++) {
                if (r >= 0 && r < rows && c >= 0 && c < cols && !(r == row && c == col)) {
                    if (grid[r][c]) {
                        count++;
                    }
                }
            }
        }
        return count;
    }
    
    // Method to find living cell locations
    public static int[][] findLivingCellLocations(boolean[][] generation) {
        int count = 0;
        
        // Count number of living cells
        for (boolean[] row : generation) {
            for (boolean cell : row) {
                if (cell) count++;
            }
        }
        
        int[][] locations = new int[count][2];
        int index = 0;
        
        // Store positions of living cells
        for (int r = 0; r < generation.length; r++) {
            for (int c = 0; c < generation[0].length; c++) {
                if (generation[r][c]) {
                    locations[index][0] = r;
                    locations[index][1] = c;
                    index++;
                }
            }
        }
        return locations;
    }
}