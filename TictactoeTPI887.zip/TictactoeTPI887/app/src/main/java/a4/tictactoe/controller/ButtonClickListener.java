package a4.tictactoe.controller;


import android.view.View;
    // button clicks class
public class ButtonClickListener implements View.OnClickListener {
    private int row;
    private int col;
    private TicTacToeController controller;
    // constructs the button click listener
    public ButtonClickListener(int row, int col, TicTacToeController controller) {
        this.row = row;
        this.col = col;
        this.controller = controller;
    }
    // handles button clicks
    @Override
    public void onClick(View v) {
        controller.handleButtonClick(row, col);
    }
}