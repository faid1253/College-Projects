package a4.tictactoe.model;

public class TicTacToeBoard {
    private Marker[][] board;

    public TicTacToeBoard() {
        board = new Marker[3][3];
    }
//* Adds a marker to the board. Returns true if successful, false otherwise.
    public boolean addMarker(Position position, Marker marker) {
        if (board[position.getRowNum()][position.getColNum()] == null) {
            board[position.getRowNum()][position.getColNum()] = marker;
            return true;
        }
        return false; //invalid moves
    }
// checks if a player has won the game
    public Position[] winningPositions(Marker marker) {
        // Check rows
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == marker && board[i][1] == marker && board[i][2] == marker) {
                return new Position[]{new Position(i, 0), new Position(i, 1), new Position(i, 2)};
            }
        }
        // Check columns
        for (int j = 0; j < 3; j++) {
            if (board[0][j] == marker && board[1][j] == marker && board[2][j] == marker) {
                return new Position[]{new Position(0, j), new Position(1, j), new Position(2, j)};
            }
        }
        // Check diagonals
        if (board[0][0] == marker && board[1][1] == marker && board[2][2] == marker) {
            return new Position[]{new Position(0, 0), new Position(1, 1), new Position(2, 2)};
        }
        if (board[0][2] == marker && board[1][1] == marker && board[2][0] == marker) {
            return new Position[]{new Position(0, 2), new Position(1, 1), new Position(2, 0)};
        }
        return null;
    }
// returns the number of nonplayable squares
    public int numUnplayedSquares() {
        int count = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == null) {
                    count++;
                }
            }
        }
        return count;
    }
//
    public void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = null;
            }
        }
    }
}