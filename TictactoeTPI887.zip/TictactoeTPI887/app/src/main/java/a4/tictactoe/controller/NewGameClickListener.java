package a4.tictactoe.controller;
import a4.tictactoe.controller.TicTacToeController;


import android.view.View;
    // handles new game button clicks
public class NewGameClickListener implements View.OnClickListener {
    private TicTacToeController controller;
    // constructs new game listener
    public NewGameClickListener(TicTacToeController controller) {
        this.controller = controller;
    }
    // handles new game clicks
    @Override
    public void onClick(View v) {
        controller.handleNewGameClick();
    }
}