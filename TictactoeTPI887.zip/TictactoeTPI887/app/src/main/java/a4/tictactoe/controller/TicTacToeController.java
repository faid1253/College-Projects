package a4.tictactoe.controller;


import android.graphics.Color;
import a4.tictactoe.model.Marker;
import a4.tictactoe.model.Position;
import a4.tictactoe.model.TicTacToeBoard;
import a4.tictactoe.view.TicTacToeView;
public class TicTacToeController {
    private TicTacToeBoard board;
    private TicTacToeView view;
    private Marker currentPlayer;
    private int xWins;
    private int oWins;
    private int draws;
    private boolean gameOver;


    public TicTacToeController(TicTacToeBoard board, TicTacToeView view) {
        this.gameOver = false; //tracks game completion
        this.board = board;
        this.view = view;
        this.currentPlayer = Marker.X; // X starts the game
        this.xWins = 0;
        this.oWins = 0;
        this.draws = 0;
        view.resetButtonsColor(); // Set all buttons to blue initially
        updateView(); //initialize the view.
    }

    //  Handles player input on game board buttons.
    public void handleButtonClick(int row, int col) {
        if (gameOver) return;  // Prevent post-game moves
        Position position = new Position(row, col);

        if (board.addMarker(position, currentPlayer)) {
            view.updateButtonText(row, col, currentPlayer.toString());

            if (checkWin(currentPlayer)) {
                handleWin();
            } else if (board.numUnplayedSquares() == 0) {
                handleDraw();
            } else {
                switchPlayer();
                updateView();
            }
        }
    }
     // Handles new game logic and alternates players

    public void handleNewGameClick() {
        gameOver = false;  // resets status
        board.resetBoard();
        view.resetButtonsColor(); // This line already sets all buttons to blue
        currentPlayer = (currentPlayer == Marker.X) ? Marker.O : Marker.X; // Alternate starting player
        updateView(); // Update the status text.
        // Clear the button texts
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                view.updateButtonText(i, j, "");

            }
        }
    }

    //switches players
    private void switchPlayer() {
        currentPlayer = (currentPlayer == Marker.X) ? Marker.O : Marker.X;
    }
    // Checks if a player has won the game and sets winning button colors
    private boolean checkWin(Marker marker) {
        Position[] winningPositions = board.winningPositions(marker);
        if (winningPositions != null) {
            for (Position position : winningPositions) {
                view.setWinningButtonColor(position.getRowNum(), position.getColNum(), Color.RED);
            }
            return true;
        }
        return false;
    }
// handles player win logic and prevents post-game moves
    private void handleWin() {
        gameOver = true;  // changes game status
        if (currentPlayer == Marker.X) {
            xWins++;
            view.setXWinsText("X Wins: " + xWins);
            view.setStatusText("Player X wins");
        } else {
            oWins++;
            view.setOWinsText("O Wins: " + oWins);
            view.setStatusText("Player O wins");
        }
    }
//handles draw logic and also prevents post-game moves
    private void handleDraw() {
        gameOver = true;  // Handles game status
        draws++;
        view.setDrawsText("Draws: " + draws);
        view.setStatusText("The game is a draw");
    }
// updates player turn
    private void updateView(){
        view.setStatusText("Ready Player " + currentPlayer.toString());
    }

}

