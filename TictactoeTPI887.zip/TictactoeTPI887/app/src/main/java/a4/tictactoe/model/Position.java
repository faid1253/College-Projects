package a4.tictactoe.model;
//* Represents a position on the board.
public class Position {
    private int rowNum;
    private int colNum;
// constructs the position for the board
    public Position(int rowNum, int colNum) {
        this.rowNum = rowNum;
        this.colNum = colNum;
    }
// gets the row and column numbers
    public int getRowNum() {
        return rowNum;
    }

    public int getColNum() {
        return colNum;
    }
}