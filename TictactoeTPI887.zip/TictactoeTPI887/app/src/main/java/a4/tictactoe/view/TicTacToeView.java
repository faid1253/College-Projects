package a4.tictactoe.view;

import android.graphics.Color;
import android.widget.Button;
import android.widget.TextView;

public class TicTacToeView {
    private TextView statusTextView;
    private Button[][] buttons;
    private TextView xWinsTextView;
    private TextView oWinsTextView;
    private TextView drawsTextView;
    private Button newGameButton;
    // constructs the view
  public TicTacToeView(TextView statusTextView, Button[][] buttons, TextView xWinsTextView, TextView oWinsTextView, TextView drawsTextView, Button newGameButton) {
        this.statusTextView = statusTextView;
        this.buttons = buttons;
        this.xWinsTextView = xWinsTextView;
        this.oWinsTextView = oWinsTextView;
        this.drawsTextView = drawsTextView;
        this.newGameButton = newGameButton;
        this.newGameButton.setBackgroundColor(Color.BLUE); // Set New Game button color
    }
    // updates button text
    public void updateButtonText(int row, int col, String text) {
        buttons[row][col].setText(text);
    }
    // sets button color
    public void setButtonColor(int row, int col, int color) {
        buttons[row][col].setBackgroundColor(color);
    }
    // resets button colors
    public void resetButtonsColor() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                setButtonColor(i, j, Color.BLUE);
            }
        }
    }
    // shows winning button color
    public void setWinningButtonColor(int row, int col, int color) {
        buttons[row][col].setBackgroundColor(color);
    }
    // sets status text
    public void setStatusText(String text) {
        statusTextView.setText(text);
    }
    // sets text for Xwin counts
    public void setXWinsText(String text) {
        xWinsTextView.setText(text);
    }
    // sets text for Owin counts
    public void setOWinsText(String text) {
        oWinsTextView.setText(text);
    }

    // sets text for draw
    public void setDrawsText(String text) {
        drawsTextView.setText(text);
    }
    // gets buttons
    public Button[][] getButtons() {
        return buttons;
    }
    // gets new game button
    public Button getNewGameButton() {
        return newGameButton;
    }
}