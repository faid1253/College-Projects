package a4.tictactoe.model;

public enum Marker { X, O}
