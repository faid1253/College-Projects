package a4.tictactoe

import a4.tictactoe.controller.ButtonClickListener
import a4.tictactoe.controller.NewGameClickListener
import a4.tictactoe.controller.TicTacToeController
import a4.tictactoe.model.TicTacToeBoard
import a4.tictactoe.view.TicTacToeView
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    //sets up the game
    private var board: TicTacToeBoard? = null
    private var view: TicTacToeView? = null
    private var controller: TicTacToeController? = null
    // sets up the view resources with buttons and strings
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        board = TicTacToeBoard()
        view = TicTacToeView(
            findViewById(R.id.directions),
            arrayOf(
                arrayOf(
                    findViewById(R.id.button_r0c0),
                    findViewById(R.id.button_r0c1),
                    findViewById(R.id.button_r0c2)
                ),
                arrayOf(
                    findViewById(R.id.button_r1c0),
                    findViewById(R.id.button_r1c1),
                    findViewById(R.id.button_r1c2)
                ),
                arrayOf(
                    findViewById(R.id.button_r2c0),
                    findViewById(R.id.button_r2c1),
                    findViewById(R.id.button_r2c2)
                )
            ),
            findViewById(R.id.x_wins),
            findViewById(R.id.o_wins),
            findViewById(R.id.draws),
            findViewById(R.id.new_game)
        )
        // sets up the controller
        controller = TicTacToeController(board, view!!)
        // sets up the buttons
        for (i in 0..2) {
            for (j in 0..2) {
                view!!.buttons[i][j].setOnClickListener(ButtonClickListener(i, j, controller!!))
            }
        }
        view!!.newGameButton.setOnClickListener(NewGameClickListener(controller!!))
    }
}