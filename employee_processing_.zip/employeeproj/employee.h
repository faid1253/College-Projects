#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#define MAX_NAME_LENGTH 10

typedef struct {
    char name[MAX_NAME_LENGTH];
    int id;
    double salary;
} Employee;

Employee* readData(const char *filename, int *size);
Employee getBestEmployee(Employee *employees, int size);
void writeData(const char *filename, Employee bestEmployee);

#endif /* EMPLOYEE_H */
