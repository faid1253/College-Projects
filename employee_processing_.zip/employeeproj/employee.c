#include "employee.h"
#include <stdio.h>
#include <stdlib.h>

Employee* readData(const char *filename, int *size) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    // Count the number of lines in the file
    int lineCount = 0;
    char ch;
    while (!feof(file)) {
        ch = fgetc(file);
        if (ch == '\n') {
            lineCount++;
        }
    }
    rewind(file);

    // Allocate memory for the array of Employee structs
    Employee *employees = (Employee *)malloc(lineCount * sizeof(Employee));
    if (employees == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }

    // Read data from the file and populate the array
    for (int i = 0; i < lineCount; i++) {
        fscanf(file, "%9s %d %lf", employees[i].name, &employees[i].id, &employees[i].salary);
    }

    // Update the size of the array
    *size = lineCount;

    fclose(file);
    return employees;
}

Employee getBestEmployee(Employee *employees, int size) {
    Employee bestEmployee = employees[0];
    for (int i = 1; i < size; i++) {
        if (employees[i].salary > bestEmployee.salary) {
            bestEmployee = employees[i];
        }
    }
    return bestEmployee;
}

void writeData(const char *filename, Employee bestEmployee) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        fprintf(stderr, "Error opening file %s\n", filename);
        exit(EXIT_FAILURE);
    }

    // Write the best employee information to the file
    fprintf(file, "%s %d %.0lf\n", bestEmployee.name, bestEmployee.id, bestEmployee.salary);

    // Close the file
    fclose(file);
}
