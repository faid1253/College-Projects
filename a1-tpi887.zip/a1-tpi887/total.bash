#!/bin/bash

total=$(ls data/*.crs | wc -l)
echo "Total courses: $total"

