#!/bin/bash

read -p "Enter department code and course num: " dept_code course_num

filename="data/${dept_code^^}${course_num}.crs"

if [ -f "$filename" ]; then
	read dept_line < "$filename"
	read course_name < "$filename"
	read sched_line < "$filename"
	read course_hr < "$filename"
	read course_size < "$filename"

	read dept_code dept_name <<< "$dept_line"
	read course_sched course_start course_end <<< "$sched_line"

	echo "Course Department:  $dept_code $dept_name"
	echo "Course number: $course_num"
	echo "Course name: $course_name"
	echo "Scheduled days: $course_sched"
	echo "Course start: $course_start"
	echo "Course end: $course_end"
	echo "Credit hours: $course_hr"
	echo "Enrolled Students: $course_size"
	else echo "ERROR: no course found"
fi
