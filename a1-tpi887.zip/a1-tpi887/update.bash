#!/bin/bash

read -p "department code: " dept_code 
read -p "department name: " dept_name
read -p "course number: " course_num
read -p "course name: " course_name 
read -p "course schedule: " course_sched 
read -p "course start date: " course_start
read -p "course end date: " course_end
read -p "course credit hours: " course_hr
read -p "inital course enrollment: " course_size 

filename="data/${dept_code^^}${course_num}.crs"

 if [ -f "$filename" ]; then 
	temp_file=$(mktemp)

	read old_dept_line < "$filename"
	read old_course_name < "$filename"
	read old_sched_line < "$filename"
	read old_course_hr < "$filename"
	read old_course_size < "$filename"

	read old_dept_code old_dept_name <<< "$old_dept_line"
	read old_course_sched old_course_start old_course_end <<< "$old_sched_line"

	echo "${dept_code:-$old_dept_cold} ${dep_name:-$old_dept_name}" > "$temp_file"
	echo "${course_name:-$old_course_name}" >> "$temp_file"
	echo "${course_sched:-$old_course_sched} ${course_start:-$old_course_start} ${course_end:-$old_course_end}" >> "$temp_file"
	echo "${course_hr:-$old_course_hr}" >> "$temp_file"
	echo "${course_size:-$old_course_size}" >> "$temp_file"
	mv "$temp_file" "filename"

	date_str$(date)
	echo "[$date_str] Updated: $dept_code %course_num $course_name" >> data/queries.log

	else echo "ERROR: no course found"
fi
