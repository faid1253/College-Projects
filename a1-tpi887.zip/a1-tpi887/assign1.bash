#!/bin/bash

mkdir -p data
while true; do

	echo "Choose a option or CTRL-D to esc"
	echo "C = new course"
	echo "R = read a course"
	echo "U = update a course"
	echo "D = delete a course"
	echo "E = update enrolled std count of a course"
	echo "T = show total"

	read action

	if [[ -z "$action" ]]; then 
	break
 fi

	case "$action" in
	[Cc]) bash create.bash ;;
	[Rr]) bash read.bash ;;
	[Uu]) bash update.bash ;;
	[Dd]) bash delete.bash ;;
	[Ee]) bash enroll.bash ;;
	[Tt]) bash total.bash ;;
	*) echo "Invalid" ;;
	esac
done

