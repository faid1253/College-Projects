#!/bin/bash

read -p "enter a course dept code and number: " dept_code course_num

filename="data/${dept_code^^}${course_num}.crs"

 	if [ -f "$filename" ]; then
	rm "$filename"
	data_str$(date)
	echo "[$date_str] Deleted: $dept_code $course_num $course_name" >> data/queires.log
	echo "$course_num was succesfully deleted"
	else echo "error: course not found"
fi
