#!/bin/bash

read -p "dep code: " dept_code
read -p "dep name: " dept_name
read -p "course num: " dept_num
read -p "course seched: " course_sched
read -p "course start dt: " course_start
read -p "course end dt: " course_end
read -p "course hours: " course_hr
read -p "std enrollment num: " course_size

filename="data/${dept_code^^}${course_num}.crs"

if [ -f "$filename" ]; then
	echo " course already exists"
else
	echo "$dept_code $dept_name" > "$filename"
	echo "$course_name" >> "$filename"
	echo "$course_sched $course_start $ course_end" >> "$filename"
	echo "$course_hr" >> $filename"
	echo "$course_size >> "filename"

	date_str=$(date)
	echo "[$date_str] NEW: $dept_code $course_num $ course_name" >> data/queries.log
fi

