#!/bin/bash

	read -p "Enter a course department code and number: " dept_code course_num
	read -p "Enter an enrollment change amount: " change_amt

	filename="/data/${dept_code^^}${course_num}.crs"

	if [ -f "$filename" ]; then
	temp_file=$(mktemp)

	read dept_line < "$filename"
	read course_name < "$filename"
	read sched_line < "$filename"
	read course_hr < "$filename"
	read course_size < "$filename"

	read dept_code dept_name <<< "$dept_line"

	new_course_size=$((course_size + change_amt))

	echo "$dept_code $dept_name" > "$temp_file"
	echo "$course_name" >> "$temp_file"
	echo "$sched_line" >> "$temp_file"
	echo "$course_hr" >> "$temp_file"
	echo "$new_course_size" >> "$temp_file"

	mv "$temp_file" "$filename"
	date_str=$(date) 
	echo "[$date_str] Enrollment: $dept_code $course_name changed by $change_amt" >> data.queires.log
	else echo "ERROR: course not found"
fi


