package a3_TPI887;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Dictionary {
    private ArrayList<Translation> translations;

    public Dictionary() {
        this.translations = new ArrayList<>();
    }

    public void add(Translation translation) {
        this.translations.add(translation);
    }

    public void addTranslations(String filePath) throws IOException {
        File file = new File(filePath);
        try (Scanner scanner = new Scanner(new BufferedReader(new FileReader(file)))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                TagOccurrence tagOccurrence = TagOccurrence.nextOccurrence(line, 0);
                if (tagOccurrence != null) {
                    String tag = tagOccurrence.getText();
                    String translation = line.substring(tagOccurrence.getEndIndex()).trim();
                    if (translation.startsWith("\"") && translation.endsWith("\"")) {
                        translation = translation.substring(1, translation.length() - 1);
                    }
                    add(new Translation(tag, translation));
                }
            }
        }
    }

    public String translate(String tag) {
        for (Translation translation : translations) {
            if (translation.getTag().equals(tag)) {
                return translation.getTranslation();
            }
        }
        return tag;
    }

    @Override
    public String toString() {
        return "Dictionary{" +
                "translations=" + translations +
                '}';
    }
}