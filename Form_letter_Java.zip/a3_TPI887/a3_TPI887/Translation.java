package a3_TPI887;

public class Translation {
    private String tag;
    private String translation;

    public Translation(String tag, String translation) {
        this.tag = tag;
        this.translation = translation;
    }

    public String getTag() {
        return tag;
    }

    public String getTranslation() {
        return translation;
    }

    @Override
    public String toString() {
        return "Translation{" +
                "tag='" + tag + '\'' +
                ", translation='" + translation + '\'' +
                '}';
    }
}