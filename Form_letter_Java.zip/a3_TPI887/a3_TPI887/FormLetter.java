package a3_TPI887;

import java.io.*;
import java.util.Scanner;


public class FormLetter {
    private String templatePath;
    private Dictionary dictionary;

    public FormLetter(String templatePath) {
        this.templatePath = templatePath;
        this.dictionary = new Dictionary();
    }

    public void setDictionary(Dictionary dictionary) {
        this.dictionary = dictionary;
    }

    public String translateLine(String line) {
        StringBuilder translatedLine = new StringBuilder();
        int curr = 0;

        TagOccurrence tagOccurrence;
        while ((tagOccurrence = TagOccurrence.nextOccurrence(line, curr)) != null) {
            translatedLine.append(line, curr, tagOccurrence.getBeginIndex());
            String tag = tagOccurrence.getText();
            String translation = dictionary.translate(tag);
            translatedLine.append(translation);
            curr = tagOccurrence.getEndIndex();
        }

        translatedLine.append(line.substring(curr));
        return translatedLine.toString();
    }

    public void generate(String outputPath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(templatePath));
             PrintStream writer = new PrintStream(new FileOutputStream(outputPath))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String translatedLine = translateLine(line);
                writer.println(translatedLine);
            }

        }
    }

    public static void main(String[] args) {
        String templatePath = "template.txt";
        String translationPath = "translation.txt";
        String outputPath = "output.txt";

        FormLetter formLetter = new FormLetter(templatePath);
        Dictionary dictionary = new Dictionary();

        try {
            dictionary.addTranslations(translationPath);
            formLetter.setDictionary(dictionary);
            formLetter.generate(outputPath);
            System.out.println("Form letter generated successfully!");
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}