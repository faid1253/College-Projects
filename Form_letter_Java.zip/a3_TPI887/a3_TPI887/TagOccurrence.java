package a3_TPI887;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TagOccurrence {
    private String text;
    private int beginIndex;
    private int endIndex;

    public TagOccurrence(String text, int beginIndex, int endIndex) {
        this.text = text;
        this.beginIndex = beginIndex;
        this.endIndex = endIndex;
    }

    public String getText() {
        return text;
    }

    public int getBeginIndex() {
        return beginIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public static TagOccurrence nextOccurrence(String str, int fromIndex) {
        Pattern pattern = Pattern.compile("<[^>]+>");
        Matcher matcher = pattern.matcher(str);

        if (matcher.find(fromIndex)) {
            return new TagOccurrence(matcher.group(), matcher.start(), matcher.end());
        }

        return null;
    }

    @Override
    public String toString() {
        return "TagOccurrence{" +
                "text='" + text + '\'' +
                ", beginIndex=" + beginIndex +
                ", endIndex=" + endIndex +
                '}';
    }
}
