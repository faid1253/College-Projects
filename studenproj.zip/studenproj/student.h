/* student.h */

#ifndef STUDENT_H
#define STUDENT_H

// Define the struct for Student
typedef struct {
    int id;
    char name[11]; // 10 chars + '\0'
} Student;

// Function prototypes
void sortStudents(Student *students, int size);
void print(Student *students, int size);
Student searchStudent(Student *students, int size, int id);

#endif // STUDENT_H
