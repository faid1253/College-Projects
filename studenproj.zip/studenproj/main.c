/* main.c */

#include <stdio.h>
#include <stdlib.h>
#include "student.h"

int main(int argc, char *argv[]) {
    // Check if command line argument is provided
    if (argc != 2) {
        printf("ERROR NO ARGS\n");
        return 1;
    }

    // Open the file for reading
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("ERROR FILE NOT OPEN\n");
        return 1;
    }

    // Obtain the number of records in the file
    int numRecords = 0;
    int id;
    char name[11];
    while (fscanf(file, "%d,%10s\n", &id, name) == 2) {
        numRecords++;
    }
    rewind(file);

    // Dynamically create the array of Student objects
    Student *students = (Student *)malloc(numRecords * sizeof(Student));
    if (students == NULL) {
        printf("ERROR MEMORY ALLOCATION FAILED\n");
        fclose(file);
        return 1;
    }

    // Read the file again and store student information in the array
    for (int i = 0; i < numRecords; i++) {
        fscanf(file, "%d,%10s\n", &students[i].id, students[i].name);
    }
    fclose(file);

    // Print student information
    printf("Original student information:\n");
    print(students, numRecords);

    // Sort students by id
    sortStudents(students, numRecords);

    // Print sorted student information
    printf("Sorted student information:\n");
    print(students, numRecords);

    // Ask user for student id
    int searchId;
    scanf("%d", &searchId);

    // Search for student by id
    Student foundStudent = searchStudent(students, numRecords, searchId);

    // Print information for the found student
    printf("Found student information: (%d,%s)\n", foundStudent.id, foundStudent.name);

    // Free dynamically allocated memory
    free(students);

    return 0;
}