#include <stdio.h>
#include <stdlib.h>
#include "student.h"

void print(Student *students, int numStudents) {
    for (int i = 0; i < numStudents; i++) {
        printf("(%d,%s) ", students[i].id, students[i].name);
    }
    printf("\n");
}

void sortStudents(Student *students, int numStudents) {
    for (int i = 0; i < numStudents - 1; i++) {
        for (int j = 0; j < numStudents - i - 1; j++) {
            if (students[j].id > students[j + 1].id) {
                // Swap students
                Student temp = students[j];
                students[j] = students[j + 1];
                students[j + 1] = temp;
            }
        }
    }
}

Student searchStudent(Student *students, int numStudents, int id) {
    Student notFound = {0, ""};
    for (int i = 0; i < numStudents; i++) {
        if (students[i].id == id) {
            return students[i];
        }
    }
    return notFound;
}